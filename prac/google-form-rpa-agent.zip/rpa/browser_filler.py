import re
from playwright.async_api import async_playwright
async def prefill_form(config, headless=False, keep_open=True):
    async with async_playwright() as p:
        b=await p.chromium.launch(headless=headless)
        c=await b.new_context(); pg=await c.new_page();
        await pg.goto(config['form_url'], wait_until='domcontentloaded')
        for f in config.get('fields',[]):
            t=f.get('type'); eid=f.get('entry_id'); lbl=f.get('question_label'); val=f.get('value')
            if t in ('text','paragraph') and eid:
                sel=f'[name="entry.{eid}"]';
                if await pg.locator(sel).count()>0: await pg.fill(sel, str(val))
            elif t=='date' and eid:
                m=re.match(r"(\d{4})-(\d{2})-(\d{2})$", str(val))
                if m:
                    y,mo,d=m.groups()
                    for suf,v in (('_year',y),('_month',str(int(mo))),('_day',str(int(d)))):
                        sel=f'[name="entry.{eid}{suf}"]';
                        if await pg.locator(sel).count()>0: await pg.fill(sel, v)
            elif t=='time' and eid:
                m=re.match(r"(\d{2}):(\d{2})$", str(val))
                if m:
                    hh,mm=m.groups()
                    for suf,v in (('_hour',str(int(hh))),('_minute',f"{int(mm):02d}")):
                        sel=f'[name="entry.{eid}{suf}"]';
                        if await pg.locator(sel).count()>0: await pg.fill(sel, v)
            elif t=='dropdown' and eid:
                sel=f'select[name="entry.{eid}"]'
                if await pg.locator(sel).count()>0:
                    await pg.select_option(sel, label=str(val))
            elif t=='choice':
                r=pg.get_by_role('radio', name=re.compile(rf'^{re.escape(str(val))}$', re.I))
                if await r.count()>0: await r.check()
            elif t=='checkbox':
                vals=val if isinstance(val, list) else [str(val)]
                for o in vals:
                    cb=pg.get_by_role('checkbox', name=re.compile(rf'^{re.escape(o)}$', re.I))
                    if await cb.count()>0: await cb.check()
        print('✅ Prefill done. Browser left open. (No submit).')
        if keep_open:
            try:
                while True:
                    await pg.wait_for_timeout(60000)
            except KeyboardInterrupt:
                pass
        await c.close(); await b.close()
