import os, json, re, requests
from bs4 import BeautifulSoup
import google.generativeai as genai
from dotenv import load_dotenv
load_dotenv()
api=os.environ.get('GEMINI_API_KEY') or os.environ.get('GOOGLE_API_KEY')
assert api, 'Set GEMINI_API_KEY'
genai.configure(api_key=api)
MODEL='models/gemini-2.5-flash'

def fetch_form_html(u):
    r=requests.get(u,timeout=30); r.raise_for_status(); return r.text

def summarize_form_fields(html):
    s=BeautifulSoup(html,'lxml')
    fields={}
    for inp in s.select('input[name^="entry."]'):
        name=inp.get('name','');
        if not name.startswith('entry.'): continue
        eid=name.split('.',1)[1]
        t=inp.get('type','text').lower()
        ft='text';
        if t=='radio': ft='choice'
        elif t=='checkbox': ft='checkbox'
        fields.setdefault(eid,{'entry_id':eid,'type':ft,'options':set(),'question_label':''})
    for ta in s.select('textarea[name^="entry."]'):
        eid=ta.get('name','').split('.',1)[1]
        fields.setdefault(eid,{'entry_id':eid,'type':'paragraph','options':set(),'question_label':''})
    for sel in s.select('select[name^="entry."]'):
        eid=sel.get('name','').split('.',1)[1]
        f=fields.setdefault(eid,{'entry_id':eid,'type':'dropdown','options':set(),'question_label':''})
        for o in sel.find_all('option'):
            txt=(o.get_text() or '').strip();
            if txt: f['options'].add(txt)
    # naive label grab
    for eid in list(fields):
        rep=s.select_one(f'[name="entry.{eid}"]')
        if rep:
            lab=rep.find_parent().get_text(' ', strip=True)
            fields[eid]['question_label']=lab[:200]
    out=[]
    for eid,f in fields.items():
        out.append({'entry_id':eid,'question_label':f.get('question_label',''),'type':f['type'],'options':sorted(list(f['options']))})
    return out

def call_gemini(url, summary, basic, prompt_path):
    prompt=open(prompt_path,'r',encoding='utf-8').read()
    model=genai.GenerativeModel(MODEL)
    resp=model.generate_content([{ 'role':'user','parts':[{'text':prompt},{'text':'FORM_URL\n'+url},{'text':'FORM_HTML_SUMMARY\n'+json.dumps(summary,indent=2)},{'text':'BASIC_INFO\n'+json.dumps(basic,indent=2)}]}])
    txt=resp.text or '{}'
    m=re.search(r"\{[\s\S]*\}\s*$", txt.strip())
    j=txt if m is None else m.group(0)
    return json.loads(j)

def build_config_from_gemini(url, basic, system_prompt_path='prompts/mapping_prompt.md'):
    html=fetch_form_html(url)
    summ=summarize_form_fields(html)
    cfg=call_gemini(url, summ, basic, system_prompt_path)
    cfg['form_url']=url
    return cfg
