# Google Form RPA Agent (Gemini 2.5-flash + Playwright, **no submit**)

See quick start inside; uses env var GEMINI_API_KEY, generates config.json via Gemini, then opens Chromium to prefill (no submit).